1:"$Sreact.fragment"
2:I[56132,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/d574f6b0e2f78a7f.js","/_next/static/chunks/5cb16278cb254626.js","/_next/static/chunks/a9d61ede4d439790.js"],"default"]
3:I[43952,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/d574f6b0e2f78a7f.js","/_next/static/chunks/5cb16278cb254626.js","/_next/static/chunks/a9d61ede4d439790.js"],"default"]
4:I[93283,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/d574f6b0e2f78a7f.js","/_next/static/chunks/5cb16278cb254626.js","/_next/static/chunks/a9d61ede4d439790.js"],"default"]
5:I[36954,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/d574f6b0e2f78a7f.js","/_next/static/chunks/5cb16278cb254626.js","/_next/static/chunks/a9d61ede4d439790.js"],"default"]
6:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
7:"$Sreact.suspense"
0:{"buildId":"2H6rfA38Fyotv85a5AJ1U","rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-gold-gradient text-white overflow-x-hidden","children":[["$","$L2",null,{}],["$","$L3",null,{"title":"Frequently Asked Questions","description":"Find answers to common questions about digital gold, buying, selling, and redemption."}],["$","$L4",null,{}],["$","$L5",null,{}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/d574f6b0e2f78a7f.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/5cb16278cb254626.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/a9d61ede4d439790.js","async":true}]],["$","$L6",null,{"children":["$","$7",null,{"name":"Next.MetadataOutlet","children":"$@8"}]}]]}],"loading":null,"isPartial":false}
8:null
