1:"$Sreact.fragment"
2:I[26998,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/fff17f7aed431e40.js","/_next/static/chunks/a5bda62110a50cfa.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"2H6rfA38Fyotv85a5AJ1U","rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-gold-gradient text-white","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/ff1a16fafef87110.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/fff17f7aed431e40.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/a5bda62110a50cfa.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
