1:"$Sreact.fragment"
2:I[56132,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/501e4e29c3822718.js","/_next/static/chunks/5cb16278cb254626.js","/_next/static/chunks/a9d61ede4d439790.js"],"default"]
3:I[43952,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/501e4e29c3822718.js","/_next/static/chunks/5cb16278cb254626.js","/_next/static/chunks/a9d61ede4d439790.js"],"default"]
4:I[30367,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/501e4e29c3822718.js","/_next/static/chunks/5cb16278cb254626.js","/_next/static/chunks/a9d61ede4d439790.js"],"default"]
5:I[36954,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/501e4e29c3822718.js","/_next/static/chunks/5cb16278cb254626.js","/_next/static/chunks/a9d61ede4d439790.js"],"default"]
6:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
7:"$Sreact.suspense"
0:{"buildId":"2H6rfA38Fyotv85a5AJ1U","rsc":["$","$1","c",{"children":[["$","main",null,{"className":"","children":[["$","$L2",null,{}],["$","$L3",null,{"title":"About Us","description":"We are building a trusted platform for digital gold investment. Our mission is to make 24K gold accessible, secure, and simple for everyone."}],["$","$L4",null,{}],["$","$L5",null,{}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/501e4e29c3822718.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/5cb16278cb254626.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/a9d61ede4d439790.js","async":true}]],["$","$L6",null,{"children":["$","$7",null,{"name":"Next.MetadataOutlet","children":"$@8"}]}]]}],"loading":null,"isPartial":false}
8:null
