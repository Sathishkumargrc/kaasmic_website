var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/blog/route.js")
R.c("server/chunks/[root-of-the-server]__96be7316._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_blog_route_actions_b02c1c70.js")
R.m(78088)
module.exports=R.m(78088).exports
