globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/669cbb8ee9021463.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/38eb66a58ed5ffd7.js",
    "static/chunks/ecef2a6275901125.js",
    "static/chunks/turbopack-4bf0ad8c76599b53.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];