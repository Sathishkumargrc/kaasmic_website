1:"$Sreact.fragment"
2:I[26998,["/_next/static/chunks/c4e609fd9b32f2be.js","/_next/static/chunks/c720d87b5c74551d.js","/_next/static/chunks/b8a2850134d7b1f3.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"MTmG_ZG0Y8knVkeNnvS3U","rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-gold-gradient text-white","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/c720d87b5c74551d.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/b8a2850134d7b1f3.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
